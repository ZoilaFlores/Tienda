<?php
// Text
$_['text_title']  = 'Servicio Postal Estados Unidos';
$_['text_weight'] = 'Peso:';
$_['text_eta']    = 'Tiempo estimado:';
?>