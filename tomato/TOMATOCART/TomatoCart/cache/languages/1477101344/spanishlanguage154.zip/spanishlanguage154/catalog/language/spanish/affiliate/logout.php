<?php
// Heading 
$_['heading_title'] = 'Salir';

// Text
$_['text_message']  = '<p>Has cerrado tu cuenta. Ahora es seguro abandonar el ordenador.</p><p>Tu cesta de la compra ha sido guardada, los productos de la cesta de la compra se restaurán cuando inicies sesión de nuevo.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';
?>