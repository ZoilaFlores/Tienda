<?php
// Text
$_['text_subject']  = '%s te ha enviado un vale regalo';
$_['text_greeting'] = 'Felicitaciones, ha recibido un vale regalo por valor de %s';
$_['text_from']     = 'Este vale regalo le ha sido enviado debido a %s';
$_['text_message']  = 'Con el siguiente mensaje:';
$_['text_redeem']   = 'Para canjear este vale regalo, anote el código de reembolso que es <b>% s </ b> y haga clic en el enlace de abajo para usar este vale regalo en la comprar de cualquiera de nuestros productos. Puede introducir el código de este vale regalo en la página del cesta de la compra justo antes de hacer clic en pagar.';
$_['text_footer']   = 'Por favor, conteste a este e-mail si tiene cualquier duda.';
?>
