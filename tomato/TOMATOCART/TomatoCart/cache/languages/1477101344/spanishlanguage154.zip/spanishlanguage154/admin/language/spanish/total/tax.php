<?php
// Heading
$_['heading_title']    = 'Impuestos';

// Text
$_['text_total']       = 'Total pedido';
$_['text_success']     = 'Éxito: has modificado total de impuestos!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar total de impuestos!';
?>