<?php
// Heading
$_['heading_title'] = 'Tu cuenta de afiliados ha sido creada!';

// Text 
$_['text_approval'] = '<p>Gracias por registrar una cuenta de afiliados con %s!</p><p>Te notificaremos por correo una vez que tu cuenta haya sido aprobada.</p><p>Si tienes alguna pregunta sobre la operativa del sistema de afiliados, por favor <a href="%s">contacta con nosotros</a>.</p>';
$_['text_account']  = 'Cuenta';
$_['text_success']  = 'Éxito';
?>
