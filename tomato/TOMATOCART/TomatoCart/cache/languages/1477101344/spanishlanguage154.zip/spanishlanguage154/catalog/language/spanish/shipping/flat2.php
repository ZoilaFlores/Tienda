<?php
// Text
$_['text_title']       = 'Envio Urgente 24h/48h';
$_['text_description'] = 'Envío a casa 24h/48h';
?>
