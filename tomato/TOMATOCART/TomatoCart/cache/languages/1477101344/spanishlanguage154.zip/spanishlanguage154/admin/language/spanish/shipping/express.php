<?php
// Heading
$_['heading_title']    = 'Envio tarifa express';

// Text
$_['text_shipping']    = 'Envío';
$_['text_success']     = 'Correcto: has modificado envío tarifa express!';

// Entry
$_['entry_cost']       = 'Coste:';
$_['entry_tax']        = 'Tipo de impuesto:';
$_['entry_geo_zone']   = 'Geo Zona:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar envío tarifa express!';
?>
