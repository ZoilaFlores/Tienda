<?php
// Heading 
$_['heading_title']      = 'Mi cuenta';

// Text
$_['text_account']       = 'Cuenta';
$_['text_my_account']    = 'Mi cuenta';
$_['text_my_orders']     = 'Mis pedidos';
$_['text_my_newsletter'] = 'Boletín de noticias';
$_['text_edit']          = 'Editar tu información de cuenta';
$_['text_password']      = 'Cambia tu contraseña';
$_['text_address']       = 'Modificar tus entradas de libro de direcciones';
$_['text_wishlist']      = 'Modificar tu lista de deseos';
$_['text_order']         = 'Ver tu historial de pedidos';
$_['text_download']      = 'Descargas';
$_['text_reward']        = 'Tus puntos recompensa'; 
$_['text_return']        = 'Ver tus peticiones de devolución'; 
$_['text_transaction']   = 'Tus transacciones'; 
$_['text_newsletter']    = 'Suscribir / Darse de baja del boletín de noticias';
?>