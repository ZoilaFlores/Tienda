<?php
// Heading
$_['heading_title']     = 'Informe de Clientes Online';

// Text 
$_['text_guest']        = 'Invitado';
 
// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Cliente';
$_['column_url']        = 'Última Página Visitada';
$_['column_referer']    = 'Referer';
$_['column_date_added'] = 'Último Click';
$_['column_action']     = 'Acción';
?>
