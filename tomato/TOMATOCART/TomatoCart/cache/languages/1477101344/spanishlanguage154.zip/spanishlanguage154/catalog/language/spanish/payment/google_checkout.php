<?php
// Entry
$_['entry_postcode'] = 'Código postal:';
$_['entry_country']  = 'País:';
$_['entry_zone']     = 'Región / Estado:';
?>