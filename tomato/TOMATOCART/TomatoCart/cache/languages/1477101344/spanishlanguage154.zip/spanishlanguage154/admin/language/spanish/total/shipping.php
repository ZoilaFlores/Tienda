<?php
// Heading
$_['heading_title']    = 'Envío';

// Text
$_['text_total']       = 'Total pedido';
$_['text_success']     = 'Éxito: has modificado envíos!';

// Entry
$_['entry_estimator']  = 'Estimador envío:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar total envíos!';
?>