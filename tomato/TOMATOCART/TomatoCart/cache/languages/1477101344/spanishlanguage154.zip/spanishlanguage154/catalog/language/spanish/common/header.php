<?php
// Text
$_['text_home']     = 'Inicio';
$_['text_wishlist'] = 'Lista de deseos (%s)';
$_['text_shopping_cart']     = 'Cesta';
$_['text_search']   = 'Búsqueda';
$_['text_welcome']  = 'Puedes <a href="%s">iniciar sesión</a> o <a href="%s">crear una cuenta</a>';
$_['text_logged']   = 'Has iniciado sesión como <a href="%s">%s</a> <b>(</b> <a href="%s">Salir</a> <b>)</b>';
$_['text_account']  = 'Mi cuenta';
$_['text_checkout'] = 'Pagar';
?>
