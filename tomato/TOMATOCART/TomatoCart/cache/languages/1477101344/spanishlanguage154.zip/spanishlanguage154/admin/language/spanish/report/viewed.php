<?php
// Heading
$_['heading_title']  = 'Informe Productos Vistos';

// Text
$_['text_success']   = 'Correcto: Has reiniciado los informes de productos vistos!';

// Column
$_['column_name']    = 'Nombre producto';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visto';
$_['column_percent'] = 'Porcentaje';
?>
