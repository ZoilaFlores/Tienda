<?php
// Heading 
$_['heading_title'] = 'Los Más Vendidos';

// Text
$_['text_reviews']  = 'Basado en %s opiniones.'; 
?>
