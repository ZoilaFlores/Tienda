<?php
// Text
$_['text_title']       = 'Envío Tarifa Correos';
$_['text_description'] = 'Envío Tarifa Correos';
?>
