<?php
// Heading
$_['heading_title']    = 'Envío tarifa fija 2';

// Text
$_['text_shipping']    = 'Envío';
$_['text_success']     = 'Éxito: has modificado envío tarifa fija 2!';

// Entry
$_['entry_cost']       = 'Coste:';
$_['entry_tax_class']  = 'Tipo de impuesto:';
$_['entry_geo_zone']   = 'Geo Zona:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';
$_['entry_tax_class']  = 'Impuestos:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar envío tarifa fija 2!';
?>
