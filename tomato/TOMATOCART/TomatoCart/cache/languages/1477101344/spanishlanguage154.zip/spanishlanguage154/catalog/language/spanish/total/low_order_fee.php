<?php
$_['text_low_order_fee'] = 'Tarifa pedido baja:';
?>