<?php
// Heading
$_['heading_title']     = 'Informe de Comisiones Afiliados';

// Column
$_['column_affiliate']  = 'Nombre Afiliado';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Estado';
$_['column_commission'] = 'Commisión';
$_['column_orders']     = 'No. Pedidos';
$_['column_total']      = 'Total';
$_['column_action']     = 'Acción';

// Entry
$_['entry_date_start']  = 'Fecha Inicio:';
$_['entry_date_end']    = 'Fecha Fin:';
?>
