<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'Producto Feeds';
$_['text_success']     = 'Éxito: has modificado el feed Google Sitemap!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_data_feed']  = 'Url feed de datos:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el feed Google Sitemap!';
?>