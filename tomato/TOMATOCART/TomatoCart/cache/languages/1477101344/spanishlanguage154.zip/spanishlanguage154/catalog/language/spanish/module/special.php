<?php
// Heading 
$_['heading_title'] = 'Ofertas';

// Text
$_['text_reviews']  = 'Basado en %s valoraciones.'; 
?>
