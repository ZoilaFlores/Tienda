<?php
// Text
$_['text_information']  = 'Información';
$_['text_service']      = 'Servicio Clientes';
$_['text_extra']        = 'Extras';
$_['text_account']      = 'Cuenta';
$_['text_contact']      = 'Contacto';
$_['text_return']       = 'Devoluciones';
$_['text_sitemap']      = 'Mapa del Sitio';
$_['text_manufacturer'] = 'Marcas';
$_['text_voucher']      = 'Vales Regalo';
$_['text_affiliate']    = 'Afiliados';
$_['text_special']      = 'Ofertas Especiales';
$_['text_login']        = 'Inicio Sesión';
$_['text_order']        = 'Historial Pedidos';
$_['text_wishlist']     = 'Lista de Deseos';
$_['text_newsletter']   = 'Boletín de Noticias';
$_['text_powered']      = '%s &copy; %s<br />Powered By <a href="http://www.opencart.com">Opencart</a><p><br /></p>';
?>
