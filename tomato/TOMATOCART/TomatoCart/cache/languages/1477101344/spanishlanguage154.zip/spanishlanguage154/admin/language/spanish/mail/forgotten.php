<?php
// Text
$_['text_subject']  = '%s - Reseteo de contraseña';
$_['text_greeting'] = 'Una nueva contraseña fue pedida por el administrador %s.';
$_['text_change']   = 'Para resetear tu contraseña haz click en el enlace inferior:';
$_['text_ip']       = 'La Ip usada para la petición fue:';
?>