<?php
// Text
$_['text_title'] = 'Tarjeta de Credito - VISA / MASTERCARD';
?>
