<?php
// Text
$_['text_title']           = 'Tarjeta de débito o crédito (procesado con seguridad por PayPal)';
$_['text_credit_card']     = 'Detalles tarjeta de crédito';
$_['text_start_date']      = '(si está disponible)';
$_['text_issue']           = '(solo tarjetas Maestro y Solo)';
$_['text_wait']            = 'Por favor espera!';

// Entry
$_['entry_cc_type']        = 'Tipo tarjeta:';
$_['entry_cc_number']      = 'Número tarjeta:';
$_['entry_cc_start_date']  = 'Tarjeta válida desde :';
$_['entry_cc_expire_date'] = 'Fecha caducidad tarjeta:';
$_['entry_cc_cvv2']        = 'Código seguridad tarjeta (CVV2):';
$_['entry_cc_issue']       = 'Número emisión tarjeta:';
?>