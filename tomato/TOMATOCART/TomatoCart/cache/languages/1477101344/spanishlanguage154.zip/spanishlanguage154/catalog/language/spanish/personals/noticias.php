<?php
// Heading
$_['heading_title'] = 'Noticies';
$_['config_meta_description'] = 'Vols saber què està passant a Informàtica Palafrugell? No t\'ho perdis. Entra i entera\'t d\'aquestes i altres qüestions!';
$_['text_noticias'] = 'Noticies';
// Text

?>
