<?php
// Heading 
$_['heading_title'] = 'Salir';

// Text
$_['text_message']  = '<p>Has cerrado sesión.</p><p>Tu cesta de la compra ha sido guardada. Podrás ver los productos en tu cesta la próxima vez que inicies sesión con tu cuenta.</p>';
$_['text_account']  = 'Cuenta';
$_['text_logout']   = 'Salir';
?>
