<?php
// Heading
$_['heading_title']    = 'Tarifa manipulación';

// Text
$_['text_total']       = 'Total pedido';
$_['text_success']     = 'Éxito: has modificado el total de tarifa de manipulación!';

// Entry
$_['entry_total']      = 'Total pedido:';
$_['entry_fee']        = 'Tarifa:';
$_['entry_tax']        = 'Tipo de impuesto:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el total de tarifa de manipulación!';
?>