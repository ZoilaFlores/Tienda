<?php
// Heading 
$_['heading_title'] = 'Aplicar código descuento';

// Text
$_['text_coupon']   = 'Cupón(%s):';
$_['text_success']  = 'Éxito: Tu cupón descuento ha sido aplicado!';

// Entry
$_['entry_coupon']  = 'Introduce tu cupón aquí:';

// Error
$_['error_coupon']  = 'Error: El cupón es invalido, ha expirado o ha alcanzado el límite de uso!';
?>