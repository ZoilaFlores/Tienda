<?php
// Heading 
$_['heading_title'] = 'Destacados';

// Text
$_['text_reviews']  = 'Basado en %s valoraciones.'; 
?>