<?php
// Heading 
$_['heading_title']    = 'Suscripción Boletín de noticias';

// Text
$_['text_account']     = 'Cuenta';
$_['text_newsletter']  = 'Boletín de noticias';
$_['text_success']     = 'Éxito: Tu suscripción al boletín de noticias ha sido actualizada satisfactoriamente!';

// Entry
$_['entry_newsletter'] = 'Suscribir:';
?>
