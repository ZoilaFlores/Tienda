<?php
// Heading
$_['heading_title']    = 'Vale regalo';

// Text
$_['text_total']       = 'Total pedido';
$_['text_success']     = 'Éxito: has modificado el total de vale regalo!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el total de vale regalo!';
?>