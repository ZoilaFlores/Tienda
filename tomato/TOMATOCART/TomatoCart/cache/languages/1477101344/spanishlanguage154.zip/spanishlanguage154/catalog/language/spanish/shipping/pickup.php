<?php
// Text
$_['text_title']       = 'Recogida';
$_['text_description'] = 'Recogida en Tienda';
?>