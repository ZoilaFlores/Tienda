<?php
// Heading
$_['heading_title']    = 'Informe de Cupones';

// Column
$_['column_name']      = 'Nombre Cupón';
$_['column_code']      = 'Código';
$_['column_orders']    = 'Pedidos';
$_['column_total']     = 'Total';
$_['column_action']    = 'Acción';

// Entry
$_['entry_date_start'] = 'Fecha Inicio:';
$_['entry_date_end']   = 'Fecha Fin:';
?>
