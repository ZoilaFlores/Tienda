<?php
// Heading
$_['heading_title']         = 'Informe de Pedido Clientes';

// Text
$_['text_all_status']       = 'Todos los Estados';

// Column
$_['column_customer']       = 'Nombre Cliente';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Grupo Cliente';
$_['column_status']         = 'Estado';
$_['column_orders']         = 'No. Pedidos';
$_['column_products']       = 'No. Productos';
$_['column_total']          = 'Total';
$_['column_action']         = 'Acción';

// Entry
$_['entry_date_start']      = 'Fecha Inicio:';
$_['entry_date_end']        = 'Fecha Fin:';
$_['entry_status']          = 'Estado Pedido:';
?>
