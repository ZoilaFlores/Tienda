<?php
$_['text_payment_type'] = 'Cargo por tipo de pago';
?>
