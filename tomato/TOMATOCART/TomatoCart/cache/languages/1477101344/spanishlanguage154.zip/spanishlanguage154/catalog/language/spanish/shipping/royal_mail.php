<?php
// Text
$_['text_title']                = 'Royal Mail';
$_['text_weight']               = 'Peso:';
$_['text_insurance']            = 'Asegurado hasta:';
$_['text_eta']                  = 'Tiempo estimado:';
$_['text_1st_class_standard']   = 'Paquete primera clase standar';
$_['text_1st_class_recorded']   = 'Paquete primera clase registrado';
$_['text_2nd_class_standard']   = 'Paquete segunda clase standar';
$_['text_2nd_class_recorded']   = 'Paquete segunda clase registrado';
$_['text_standard_parcels']     = 'Parcela estándar';
$_['text_airmail']              = 'Correo aereo';
$_['text_international_signed'] = 'Firmado internacional';
$_['text_airsure']              = 'Airsure';
$_['text_surface']              = 'Superficie';
?>