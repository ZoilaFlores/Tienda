<?php
// Heading 
$_['heading_title']   = 'Descargas';

// Text
$_['text_account']    = 'Cuenta';
$_['text_downloads']  = 'Descargas';
$_['text_order']      = 'ID pedido:';
$_['text_date_added'] = 'Fecha alta:';
$_['text_name']       = 'Nombre:';
$_['text_remaining']  = 'Restantes:';
$_['text_size']       = 'Tamaño:';
$_['text_download']   = 'Descarga';
$_['text_empty']      = 'No has pedido nada descargable con anterioridad!';
?>