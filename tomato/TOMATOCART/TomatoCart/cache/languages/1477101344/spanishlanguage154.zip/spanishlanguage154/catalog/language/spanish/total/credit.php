<?php
$_['text_credit']   = 'Crédito Tienda';
$_['text_order_id'] = 'ID pedido: #%s';
?>
