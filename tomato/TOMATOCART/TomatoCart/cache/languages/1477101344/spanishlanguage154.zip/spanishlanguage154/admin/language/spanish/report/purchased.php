<?php
// Heading
$_['heading_title']   = 'Informe de Productos Comprados';

// Column
$_['column_name']     = 'Nombre producto';
$_['column_model']    = 'Modelo';
$_['column_quantity'] = 'Cantidad';
$_['column_total']    = 'Total';
?>
