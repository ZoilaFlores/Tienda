<?php
// Heading 
$_['heading_title'] = 'Cesta';

// Text
$_['text_items']    = '%s producto(s) - %s';
$_['text_empty']    = 'La cesta esta vacía!';
$_['text_cart']     = 'Ver Cesta';
$_['text_checkout'] = 'Pagar';
?>
