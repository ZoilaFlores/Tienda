<?php
// Text
$_['text_title']       = 'Por ítem';
$_['text_description'] = 'Tarifa de envío por ítem';
?>