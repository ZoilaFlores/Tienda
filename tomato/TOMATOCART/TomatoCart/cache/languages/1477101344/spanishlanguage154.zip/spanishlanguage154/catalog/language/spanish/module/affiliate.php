<?php
// Heading 
$_['heading_title']    = 'Afiliados';

// Text
$_['text_register']    = 'Registro';
$_['text_login']       = 'Inicio sesión';
$_['text_logout']      = 'Salir';
$_['text_forgotten']   = 'Contraseña olvidada';
$_['text_account']     = 'Mi cuenta';
$_['text_edit']        = 'Editar cuenta';
$_['text_password']    = 'Contraseña';
$_['text_payment']     = 'Opciones de pago';
$_['text_tracking']    = 'Seguimiento afiliados';
$_['text_transaction'] = 'Transacciones';
?>
