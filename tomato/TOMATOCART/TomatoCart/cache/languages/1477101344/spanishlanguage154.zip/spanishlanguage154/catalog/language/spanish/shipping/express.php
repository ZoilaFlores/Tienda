<?php
// Text
$_['text_title']       = 'Envio Tarifa Expres (Nacex/Postal Express)';
$_['text_description'] = 'Envío tarifa expres con Nacex / Postal Express';
?>
