<?php
// Text
$_['text_subject']  = 'Te han enviado un cheque regalo de %s';
$_['text_greeting'] = 'Enhorabuena, has recibido un cheque regalo por valor de %s';
$_['text_from']     = 'Este cheque regalo te lo ha enviado  %s';
$_['text_message']  = 'Con el siguiente mensaje';
$_['text_redeem']   = 'Para utilizar este cheque regalo, escribe el código del cheque que es <b>%s</b> luego haz click en el enlace inferior y compra el producto en el que desees utilizar este cheque. Puedes utilizar este código de cheque en la cesta de la compra antes de realizar la compra.';
$_['text_footer']   = 'Por favor contesta este correo si tienes alguna duda.';
?>