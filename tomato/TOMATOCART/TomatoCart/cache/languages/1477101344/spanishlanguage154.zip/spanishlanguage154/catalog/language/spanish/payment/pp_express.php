<?php
// Text
$_['text_title'] = 'PayPal Express (incluyento tarjeta de crédito y tarjeta de débito)';
?>