<?php
// Text
$_['text_subject']       = '%s - Actualización devolución %s';
$_['text_return_id']     = 'ID devolución:';
$_['text_date_added']    = 'Fecha devolución:';
$_['text_return_status'] = 'Tu devolución ha sido actualizado al siguiente estado:';
$_['text_comment']       = 'El comentario para tu devolución es:';
$_['text_footer']        = 'Por favor contesta a este email si tienes alguna duda.';
?>