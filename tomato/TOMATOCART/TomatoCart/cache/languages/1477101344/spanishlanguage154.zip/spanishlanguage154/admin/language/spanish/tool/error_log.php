<?php
// Heading
$_['heading_title'] = 'Log Error';

// Text
$_['text_success']  = 'Éxito: Has limpiado el log de error satisfactoriamente!';
?>