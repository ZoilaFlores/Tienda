<?php
// Heading 
$_['heading_title']      = 'Tus puntos recompensa';

// Column
$_['column_date_added']  = 'Fecha alta';
$_['column_description'] = 'Description';
$_['column_points']      = 'Puntos';

// Text
$_['text_account']       = 'Cuenta';
$_['text_reward']        = 'Puntos recompensa';
$_['text_total']         = 'El total de tus puntos de recompensa es:';
$_['text_empty']         = 'No tienes ningún punto recompensa!';
?>
