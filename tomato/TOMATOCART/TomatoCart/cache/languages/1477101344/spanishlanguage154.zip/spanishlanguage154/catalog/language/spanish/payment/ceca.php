<?php
// Text
$_['text_title'] = 'TARJETA DE CREDITO VISA - MASTERCARD';
?>
