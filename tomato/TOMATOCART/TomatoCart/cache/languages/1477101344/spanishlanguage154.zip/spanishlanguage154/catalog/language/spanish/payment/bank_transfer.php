<?php
// Text
$_['text_title']       = 'TRANSFERENCIA BANCARIA';
$_['text_instruction'] = 'Instrucciones transferencia bancaria';
$_['text_description'] = 'Por favor transfiera la cantidad total del pedido a la siguiente cuenta bancaria.';
$_['text_payment']     = 'Su pedido no se enviará hasta recibir el pago.';
?>
