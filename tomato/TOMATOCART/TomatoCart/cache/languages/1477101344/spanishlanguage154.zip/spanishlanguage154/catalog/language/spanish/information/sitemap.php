<?php
// Heading
$_['heading_title']    = 'Mapa del sitio';
 
// Text
$_['text_special']     = 'Ofertas especiales';
$_['text_account']     = 'Mi cuenta';
$_['text_edit']        = 'Información de cuenta';
$_['text_password']    = 'Contraseña';
$_['text_address']     = 'Libro direcciones';
$_['text_history']     = 'Historial pedidos';
$_['text_download']    = 'Descargas';
$_['text_cart']        = 'Cesta';
$_['text_checkout']    = 'Compra';
$_['text_search']      = 'Búsqueda';
$_['text_information'] = 'Información';
$_['text_contact']     = 'Contáctanos';
?>
