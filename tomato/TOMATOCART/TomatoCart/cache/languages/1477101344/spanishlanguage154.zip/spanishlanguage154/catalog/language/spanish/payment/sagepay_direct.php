<?php
// Text
$_['text_title']           = 'Tarjeta de crédito / Tarjeta de débito (SagePay)';
$_['text_credit_card']     = 'Detalles tarjeta de crédito ';
$_['text_start_date']      = '(si está disponible)';
$_['text_issue']           = '(solo para tarjetas Maestro y Solo)';
$_['text_wait']            = 'Por favor espera!';

// Entry
$_['entry_cc_owner']       = 'Nombre tarjeta:';
$_['entry_cc_type']        = 'Tipo tarjeta:';
$_['entry_cc_number']      = 'Número Tarjeta:';
$_['entry_cc_start_date']  = 'Tarjeta válida desde:';
$_['entry_cc_expire_date'] = 'Fecha caducidad tarjeta:';
$_['entry_cc_cvv2']        = 'Código seguridad tarjeta (CVV2):';
$_['entry_cc_issue']       = 'Número emisión tarjeta:';
?>