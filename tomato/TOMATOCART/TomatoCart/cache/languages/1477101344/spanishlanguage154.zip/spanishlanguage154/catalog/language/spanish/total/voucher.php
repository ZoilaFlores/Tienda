<?php
// Heading 
$_['heading_title'] = 'Usar vale regalo';

// Text
$_['text_voucher']  = 'Vale(%s):';
$_['text_success']  = 'Éxito: Tu vale regalo de descuento ha sido aplicado!';

// Entry
$_['entry_voucher'] = 'Introduce el código de tu vale regalo aquí:';

// Error
$_['error_voucher'] = 'Error: El vale de regalo es inválido o ha sido usado!!';
?>