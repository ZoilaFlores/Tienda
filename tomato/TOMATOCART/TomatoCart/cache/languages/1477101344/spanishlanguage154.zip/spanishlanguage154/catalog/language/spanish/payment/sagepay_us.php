<?php
// Text
$_['text_title']           = 'Tarjeta de crédito / Tarjeta de débito (SagePay)';
$_['text_credit_card']     = 'Detalles tarjeta de crédito';
$_['text_wait']            = 'Por favor espera!';

// Entry
$_['entry_cc_owner']       = 'Nombre tarjeta:';
$_['entry_cc_number']      = 'Numero tarjeta:';
$_['entry_cc_expire_date'] = 'Fecha caducidad tarjeta:';
$_['entry_cc_cvv2']        = 'Código seguridad tarjeta (CVV2):';
?>