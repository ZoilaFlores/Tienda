<?php
// Text
$_['text_title'] = 'Tarjeta de crédito / Tarjeta de débito (CCAvenue)';
?>