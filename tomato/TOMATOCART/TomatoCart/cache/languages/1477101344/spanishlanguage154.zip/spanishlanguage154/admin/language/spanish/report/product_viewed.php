<?php
// Heading
$_['heading_title']  = 'Informe de Productos Vistos';

// Text
$_['text_success']   = 'Correcto: Has reiniciado correctamente el informe de productos vistos!';

// Column
$_['column_name']    = 'Nombre Producto';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visto';
$_['column_percent'] = 'Porcentaje';
?>
