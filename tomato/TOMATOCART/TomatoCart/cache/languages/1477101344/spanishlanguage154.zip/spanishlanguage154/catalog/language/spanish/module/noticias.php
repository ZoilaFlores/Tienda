<?php
// Heading 
$_['heading_title'] = 'Noticias';

// Text
$_['text_contact']  = 'Contáctanos';
$_['text_sitemap']  = 'Mapa del sitio';
?>
