<?php
$_['text_handling'] = 'Tarifa de manipulación:';
?>